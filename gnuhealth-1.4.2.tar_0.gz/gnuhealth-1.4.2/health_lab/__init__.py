# -*- encoding: utf-8 -*-
from health_lab import *
from report import *
from wizard import *
