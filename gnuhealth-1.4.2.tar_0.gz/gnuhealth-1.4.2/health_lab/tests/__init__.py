from test_gnuhealth_lab import suite
